import { MainNavbar } from "../../components";

export default function blogpost() {
  return (
    <>
      <MainNavbar />
    </>
  );
}
