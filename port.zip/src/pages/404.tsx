import { PageNotFound } from "../components";

export default function Error404() {
    return (
        <>
            <PageNotFound/>
        </>
    );
}