export interface ITimelineItem {
  position: string;
  company: string;
  from: any;
  to: any;
  roles: string;
}
